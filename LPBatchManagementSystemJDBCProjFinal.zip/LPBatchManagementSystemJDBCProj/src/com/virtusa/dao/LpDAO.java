package com.virtusa.dao;

import java.sql.SQLException;
import java.util.List;

import com.virtusa.entities.LP;

public interface LpDAO{
	
	
     LP lpProfileView(String userId) throws ClassNotFoundException, SQLException;


	boolean storeLpDetails(LP lp) throws ClassNotFoundException, SQLException;

	
}
