package com.virtusa.test;

import static org.junit.Assert.*;

import java.sql.SQLException;

import org.junit.Test;

import com.virtusa.dao.LpDAO;
import com.virtusa.dao.LpDAOImpl;
import com.virtusa.entities.LP;

public class LpViewDetailsTest {


	@Test
	public void viewLp_possitive() {
		LP lp = new LP();
		LpDAO lpDAO = new LpDAOImpl();

		try {
			String userId = lp.getLpId();
			LP lps = lpDAO.lpProfileView(userId);
			assertNotNull(lps);

		} catch (ClassNotFoundException | SQLException e) {
			assertTrue(false);
		}

	}
}
