package com.virtusa.service;

import java.sql.SQLException;
import java.util.List;
import java.util.logging.Logger;

import com.virtusa.model.LpModel;
import com.virtusa.model.UpdateLpDetailsModel;

public interface LpService {
	LpModel retrieveLpDetails(String userId);

	boolean storeLpService(UpdateLpDetailsModel updateLpDetailsView) throws ClassNotFoundException, SQLException;

}
