package com.virtusa.helper;

import org.apache.log4j.Logger;

import com.virtusa.dao.LpDAO;
import com.virtusa.dao.LpDAOImpl;
import com.virtusa.dao.UserDAO;
import com.virtusa.service.LpService;

public class FactoryLpDAO {
	public static Logger log = Logger.getLogger(FactoryLpDAO.class.getName());

	public static LpDAO createLpDAO() {
		log.info("entered into factory class");
		LpDAO lpDAO = new LpDAOImpl();
		return lpDAO;

	}
}